﻿using System;

namespace Tshirt.Models
{
    internal class keyAttribute : Attribute
    {
        public int coolingOffId { get; set; }
    }
}