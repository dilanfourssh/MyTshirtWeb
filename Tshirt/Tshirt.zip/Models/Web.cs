﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Tshirt.Models
{
    public class Web
    {
        public int id { get; set; }
        public string category { get; set; }
        public string fileName { get; set; }
        public string Name { get; set; }
        public string tagNumber { get; set; }
    }
}