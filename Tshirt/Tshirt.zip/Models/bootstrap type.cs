﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Tshirt.Models
{
    public class bootstrap_type
    {
        public int id { get; set; }
        public string name { get; set; }
        public string type { get; set; }
    }
}