﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Tshirt.Models
{
    public class CompanyRegister
    {
        public int companyRegisterId { get; set; }
        public string companyMassege { get; set; }
        public string companyName { get; set; }
        public string email { get; set; }
        public string ownerName { get; set; }
        public string ownerIdnumber { get; set; }
        public string tshirt { get; set; }
        public string tshirtprint { get; set; }
        public string offsetprint { get; set; }
        public string digitalprint { get; set; }
        public string plastic { get; set; }
        public string mug { get; set; }
        public string companylocation { get; set; }
        public string companyaddress { get; set; }
        public string agree { get; set; }
       
    }
}
